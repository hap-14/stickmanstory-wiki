THE STICKMAN STORY — GITHUB PAGES

1. Go to github.com and sign up (free).
2. Create a PUBLIC repository named stickman-wiki.
3. Choose Add file > Upload files. Upload index.html and script.js from this ZIP, directly to the repository's top level. Commit.
4. Open Settings > Pages > Build and deployment. Choose Deploy from a branch, branch main, folder /(root), Save.
5. Your free URL will be https://YOUR-USERNAME.github.io/stickman-wiki/

NOTE: This first version is a website with a searchable character archive that links to the Notion source pages. Notion pages must be published for visitors to access them. Notion changes do not automatically sync to this site. Do not publish private spoilers.
